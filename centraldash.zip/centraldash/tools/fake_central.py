#!/usr/bin/env python3
"""Central simulada para desarrollar sin estar en el auto.

Emite una línea JSON por tick en el puerto 47800 (TCP). El ESQUEMA ES INFERIDO
(ver docs/PROTOCOLO_CENTRAL.md); ajústalo cuando tengas una captura real.

Uso:  python3 tools/fake_central.py [--port 47800] [--hz 1]
Luego, en la app, escribe la IP de tu PC en el campo "IP de la central".
"""
import argparse, asyncio, json, math, time

def sample(t0: float) -> dict:
    t = time.time() - t0
    speed = max(0.0, 45 + 35 * math.sin(t / 20))
    soc = max(5.0, 80 - t / 60)
    return {
        "carId": "SIM-0001",
        "vhalLive": True,
        "soc": round(soc, 1),
        "range": round(soc * 4.1, 0),
        "speed": round(speed, 1),
        "power": round(speed * 0.18 - 2, 1),
        "odo": round(12345.6 + t * speed / 3600, 1),
        "outTemp": 22.5,
        "setTemp": 22.0,
        "aux12v": 13.6,
        "gear": "D" if speed > 0.5 else "P",
        "charging": False,
        "dcfc": False,
        "chargeKw": 0.0,
    }

async def handle(reader, writer, hz):
    peer = writer.get_extra_info("peername")
    print("cliente conectado:", peer, flush=True)
    t0 = time.time()
    try:
        while True:
            writer.write((json.dumps(sample(t0)) + "\n").encode("utf-8"))
            await writer.drain()
            await asyncio.sleep(1.0 / hz)
    except (ConnectionResetError, BrokenPipeError):
        pass
    finally:
        print("cliente desconectado:", peer, flush=True)
        writer.close()

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=47800)
    ap.add_argument("--hz", type=float, default=1.0)
    a = ap.parse_args()
    server = await asyncio.start_server(lambda r, w: handle(r, w, a.hz), "0.0.0.0", a.port)
    print(f"central simulada escuchando en :{a.port}", flush=True)
    async with server:
        await server.serve_forever()

if __name__ == "__main__":
    asyncio.run(main())
