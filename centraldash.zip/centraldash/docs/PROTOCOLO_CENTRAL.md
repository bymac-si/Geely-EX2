# Protocolo de la central (multimedia del auto)

Notas de interoperabilidad obtenidas observando el comportamiento de un cliente existente.
`[observado]` = visto en el cliente (nombres, constantes, llamadas). `[inferido]` = deducido; verificar con una captura real.

## 1. Descubrimiento
1. mDNS/NSD: servicio `_exsapo._tcp.`; el registro trae atributos TXT `id`, `vc`, `sync`. `[observado]`
2. Respaldo: IP guardada por el usuario + IPs candidatas de la red local. Una IP vale si, al conectar al puerto 47800, llega una línea JSON con claves del tipo `soc`, `odo`, `gear`, `trip`, `vhalLive`. `[observado]`

## 2. Canal principal: TCP 47800
- El cliente solo conecta y lee. La central empuja líneas JSON terminadas en `\n`, UTF-8. `[observado]`
- Con timeout de lectura, cualquier error provoca reconexión tras una espera. `[observado]`
- Cada línea es un objeto con telemetría en la raíz y/o las claves `carId`, `trip`, `charge`, `tripsDone`, `chargesDone` (sincronización de historial). `[observado]`
- Frecuencia de envío: desconocida. `[por medir]`

### Campos de telemetría (alias aceptados)
| Clave(s) JSON | Significado | Estado |
|---|---|---|
| `soc` / `socPct` | batería % | observado |
| `range` / `rangeKm` | autonomía km | observado |
| `speed` / `speedKmh` | velocidad km/h | observado |
| `power` / `instPowerKw` | potencia kW (signo por verificar) | observado / inferido |
| `odo` / `odometerKm` | odómetro km | observado |
| `outTemp` / `outsideTempC` | temp. exterior °C | observado |
| `setTemp` / `hvacTempSetC` | consigna del clima °C | observado |
| `aux12v` / `aux12vVolt` | batería 12 V | observado |
| `gearLabel` / `gear` | marcha (`P`, `R`, `N`, `D`) | observado |
| `charging`, `dcfc` | cargando / carga rápida DC | observado |
| `chargeKw` / `chargePowerKw` | potencia de carga kW | observado |
| `vhalLive` | la central recibe datos reales del vehículo | observado |
| `powerSource`, `driveFlow`, `battFlow` | origen de la potencia y flujos | observado, sin usar |

## 3. Respaldo Bluetooth clásico (RFCOMM) — no incluido en esta entrega
- UUID `b5b9a1e0-3c2f-4d6a-8f4e-7a2b9c1d0e5f`; dispositivos emparejados con nombre que contiene `GEELY`, `GOC`, `IHU` o `ECARX`. `[observado]`
- El cliente escribe `{"op":"state"}\n` y lee una línea `{"carId":..., "telemetry":{...}}` (espera máx. 8 s). `[observado]`

## 4. Respaldo BLE — no incluido en esta entrega
- Servicio `7ea9c1d4-3f62-4b18-9d5a-0c8e6f21ab70`, característica `...ab71`; JSON compacto con `g`, `vivo`, `soc`, `kw`, `kmh`, `odo`, `rng`. `[observado]`
- Autenticación por token HMAC-SHA256 sobre un contador de tiempo, con un secreto que la central entrega por `GET http://<host>:47801/sync/state` (campo `bleSegredoHex`). `[observado]`

## 5. Preguntas abiertas
1. Muestra real de una línea del puerto 47800 (para cerrar tipos, unidades y signos).
2. Frecuencia de envío y si hay latidos cuando el auto está apagado.
3. Valores posibles de `gear` y de `powerSource`.
