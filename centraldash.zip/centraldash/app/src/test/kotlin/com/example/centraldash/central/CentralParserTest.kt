package com.example.centraldash.central

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CentralParserTest {
    @Test fun `lee claves cortas`() {
        val t = CentralParser.parse("""{"soc":78.5,"speed":42,"range":310,"gear":"D","charging":false}""", 1L)
        assertNotNull(t)
        assertEquals(78.5, t!!.socPct!!, 0.001)
        assertEquals(42.0, t.speedKmh!!, 0.001)
        assertEquals("D", t.gear)
        assertEquals(false, t.charging)
    }

    @Test fun `acepta alias largos y telemetria anidada`() {
        val t = CentralParser.parse("""{"carId":"X1","telemetry":{"socPct":50,"rangeKm":200,"outsideTempC":18.5}}""")
        assertEquals("X1", t!!.carId)
        assertEquals(50.0, t.socPct!!, 0.001)
        assertEquals(18.5, t.outsideTempC!!, 0.001)
    }

    @Test fun `descarta basura y paquetes sin telemetria`() {
        assertNull(CentralParser.parse("no es json"))
        assertNull(CentralParser.parse("""{"tripsDone":3,"chargesDone":1}"""))
    }
}
