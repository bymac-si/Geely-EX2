package com.example.centraldash.model

/** Estado del auto tal como lo reporta la central. Todo es opcional: la central puede omitir campos. */
data class Telemetry(
    val carId: String? = null,
    val socPct: Double? = null,
    val rangeKm: Double? = null,
    val speedKmh: Double? = null,
    val powerKw: Double? = null,
    val odometerKm: Double? = null,
    val outsideTempC: Double? = null,
    val hvacSetC: Double? = null,
    val aux12vVolt: Double? = null,
    val gear: String? = null,
    val charging: Boolean? = null,
    val dcFastCharging: Boolean? = null,
    val chargeKw: Double? = null,
    val vehicleLive: Boolean? = null,
    val updatedAtMs: Long = 0L,
) {
    /** Hay al menos un dato de conducción reconocible. */
    fun hasData(): Boolean =
        socPct != null || rangeKm != null || speedKmh != null || odometerKm != null
}
