package com.example.centraldash.apkshare

import java.io.File

/**
 * Compartir APKs por la red local para instalarlos desde el navegador de la multimedia.
 * La implementación real solo existe en el sabor "sideload"; en "play" es un stub inactivo.
 */
interface ApkSharing {
    val available: Boolean

    /** Arranca el servidor. Devuelve las URLs para abrir en el auto, o null si no pudo. */
    fun start(dir: File, pin: String): List<String>?
    fun stop()
    fun isRunning(): Boolean
}
