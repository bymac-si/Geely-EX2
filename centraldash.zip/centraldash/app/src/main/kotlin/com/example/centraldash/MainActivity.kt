package com.example.centraldash

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.centraldash.apkshare.ApkSharingProvider
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.io.File
import java.security.SecureRandom

/** UI mínima en Views (sin Compose) para mantener el proyecto pequeño. */
class MainActivity : ComponentActivity() {

    private val pickApk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { copyApk(it) }
    }
    private lateinit var info: TextView
    private lateinit var shareInfo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        info = TextView(this).apply { textSize = 16f }
        val host = EditText(this).apply {
            hint = "IP de la central (vacío = autodetectar)"
            setText(Settings.host(this@MainActivity) ?: "")
        }
        val start = Button(this).apply {
            text = "Conectar"
            setOnClickListener {
                Settings.setHost(this@MainActivity, host.text.toString().ifBlank { null })
                startForegroundService(Intent(this@MainActivity, TelemetryService::class.java))
            }
        }
        val stop = Button(this).apply {
            text = "Desconectar"
            setOnClickListener { stopService(Intent(this@MainActivity, TelemetryService::class.java)) }
        }
        root.addView(info); root.addView(host); root.addView(start); root.addView(stop)

        val sharing = ApkSharingProvider.instance
        shareInfo = TextView(this)
        if (sharing.available) {
            root.addView(Button(this).apply { text = "Agregar APK…"; setOnClickListener { pickApk.launch(arrayOf("*/*")) } })
            root.addView(Button(this).apply {
                text = "Compartir APKs con el auto (10 min)"
                setOnClickListener {
                    val pin = "%06d".format(SecureRandom().nextInt(1_000_000))
                    val urls = sharing.start(apkDir(), pin)
                    shareInfo.text = urls?.joinToString("\n", prefix = "Abre en el navegador del auto:\n")
                        ?: "No se pudo iniciar (¿puerto ocupado?)"
                }
            })
            root.addView(Button(this).apply {
                text = "Dejar de compartir"
                setOnClickListener { sharing.stop(); shareInfo.text = "" }
            })
            root.addView(shareInfo)
        }
        setContentView(root)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                TelemetryRepo.state.combine(TelemetryRepo.status) { t, s -> t to s }.collect { (t, s) ->
                    info.text = "Estado: $s\nBatería: ${t.socPct ?: "—"} %\nAutonomía: ${t.rangeKm ?: "—"} km\n" +
                        "Velocidad: ${t.speedKmh ?: "—"} km/h\nMarcha: ${t.gear ?: "—"}"
                }
            }
        }
    }

    private fun apkDir() = File(filesDir, "apks").apply { mkdirs() }

    private fun copyApk(uri: Uri) {
        val name = (uri.lastPathSegment ?: "app").substringAfterLast('/').substringAfterLast(':')
            .replace(Regex("[^A-Za-z0-9._-]"), "_").let { if (it.endsWith(".apk", true)) it else "$it.apk" }
        contentResolver.openInputStream(uri)?.use { input ->
            File(apkDir(), name).outputStream().use { input.copyTo(it) }
        }
    }
}
