package com.example.centraldash.central

import com.example.centraldash.TelemetryRepo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Se conecta al puerto de telemetría de la central y lee líneas JSON (una por línea, UTF-8).
 * Solo lee: no envía nada. Reintenta con espera creciente.
 */
class CentralClient(private val hostProvider: suspend () -> String?) {

    @Volatile private var backoffMs = 1_000L

    suspend fun run() {
        while (currentCoroutineContext().isActive) {
            val host = hostProvider()
            if (host == null) {
                TelemetryRepo.setStatus("buscando la central…")
                delay(5_000)
                continue
            }
            try {
                readFrom(host)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                TelemetryRepo.setStatus("error: ${e.message ?: e.javaClass.simpleName}")
            }
            delay(backoffMs)
            backoffMs = (backoffMs * 2).coerceAtMost(30_000L)
        }
    }

    private suspend fun readFrom(host: String): Unit = withContext(Dispatchers.IO) {
        val socket = Socket()
        // Un readLine() bloqueante no se cancela solo: cerramos el socket al cancelar.
        val handle = coroutineContext[Job]!!.invokeOnCompletion { runCatching { socket.close() } }
        try {
            TelemetryRepo.setStatus("conectando a $host…")
            socket.connect(InetSocketAddress(host, PORT), 5_000)
            socket.soTimeout = READ_TIMEOUT_MS   // sin datos en este lapso => reconectar
            backoffMs = 1_000L
            TelemetryRepo.setStatus("conectado a $host")
            socket.getInputStream().bufferedReader(Charsets.UTF_8).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: throw IOException("la central cerró la conexión")
                    CentralParser.parse(line)?.let(TelemetryRepo::publish)
                }
            }
        } finally {
            handle.dispose()
            runCatching { socket.close() }
        }
    }

    companion object {
        const val PORT = 47800
        const val READ_TIMEOUT_MS = 20_000
    }
}
