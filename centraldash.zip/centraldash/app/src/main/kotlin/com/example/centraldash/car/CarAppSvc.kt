package com.example.centraldash.car

import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.model.Action
import androidx.car.app.model.Pane
import androidx.car.app.model.PaneTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.car.app.validation.HostValidator
import androidx.lifecycle.lifecycleScope
import com.example.centraldash.TelemetryRepo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.util.Locale

class CarAppSvc : CarAppService() {
    override fun createHostValidator(): HostValidator =
        if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) {
            HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
        } else {
            HostValidator.Builder(applicationContext)
                .addAllowedHosts(androidx.car.app.R.array.hosts_allowlist_sample)
                .build()
        }

    override fun onCreateSession(): Session = object : Session() {
        override fun onCreateScreen(intent: Intent): Screen = DashboardScreen(carContext)
    }
}

/** Pantalla IoT con 4 filas (el límite de PaneTemplate). Se refresca como máximo 1 vez por segundo. */
class DashboardScreen(carContext: CarContext) : Screen(carContext) {

    init {
        lifecycleScope.launch {
            TelemetryRepo.state.combine(TelemetryRepo.status) { t, s -> t to s }.collect {
                invalidate()
                delay(1_000)
            }
        }
    }

    override fun onGetTemplate(): Template {
        val t = TelemetryRepo.state.value
        val loc = Locale.getDefault()
        fun fmt(v: Double?, pattern: String) = v?.let { String.format(loc, pattern, it) } ?: "—"

        val pane = Pane.Builder()
            .addRow(row("Batería", fmt(t.socPct, "%.0f %%")))
            .addRow(row("Autonomía", fmt(t.rangeKm, "%.0f km")))
            .addRow(row("Potencia", fmt(t.powerKw, "%.1f kW")))
            .addRow(row("Temp. exterior", fmt(t.outsideTempC, "%.1f °C")))
            .build()

        return PaneTemplate.Builder(pane)
            .setHeaderAction(Action.APP_ICON)
            .setTitle("Central · ${TelemetryRepo.status.value}")
            .build()
    }

    private fun row(title: String, value: String) =
        Row.Builder().setTitle(title).addText(value).build()
}
