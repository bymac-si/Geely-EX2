package com.example.centraldash.central

import com.example.centraldash.model.Telemetry
import org.json.JSONObject

/**
 * Convierte una línea JSON de la central en [Telemetry].
 * Los nombres de campo y sus alias vienen de docs/PROTOCOLO_CENTRAL.md ([observado]);
 * unidades y signos están por verificar con una captura real.
 */
object CentralParser {

    fun parse(line: String, nowMs: Long = System.currentTimeMillis()): Telemetry? {
        val root = try { JSONObject(line) } catch (e: Exception) { return null }
        // TCP: telemetría en la raíz. Bluetooth clásico: dentro de "telemetry".
        val o = root.optJSONObject("telemetry") ?: root
        val t = Telemetry(
            carId = text(root, "carId"),
            socPct = num(o, "soc", "socPct"),
            rangeKm = num(o, "range", "rangeKm"),
            speedKmh = num(o, "speed", "speedKmh"),
            powerKw = num(o, "power", "instPowerKw"),
            odometerKm = num(o, "odo", "odometerKm"),
            outsideTempC = num(o, "outTemp", "outsideTempC"),
            hvacSetC = num(o, "setTemp", "hvacTempSetC"),
            aux12vVolt = num(o, "aux12v", "aux12vVolt"),
            gear = text(o, "gearLabel") ?: text(o, "gear"),
            charging = bool(o, "charging"),
            dcFastCharging = bool(o, "dcfc"),
            chargeKw = num(o, "chargeKw", "chargePowerKw"),
            vehicleLive = bool(o, "vhalLive"),
            updatedAtMs = nowMs,
        )
        return if (t.hasData()) t else null
    }

    private fun num(o: JSONObject, vararg keys: String): Double? {
        for (k in keys) {
            if (o.has(k) && !o.isNull(k)) {
                val v = o.optDouble(k, Double.NaN)
                if (!v.isNaN()) return v
            }
        }
        return null
    }

    private fun bool(o: JSONObject, key: String): Boolean? =
        if (o.has(key) && !o.isNull(key)) o.optBoolean(key) else null

    private fun text(o: JSONObject, key: String): String? =
        if (o.has(key) && !o.isNull(key)) o.optString(key).takeIf { it.isNotEmpty() } else null
}
