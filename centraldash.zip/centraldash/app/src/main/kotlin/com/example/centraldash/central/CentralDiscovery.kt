package com.example.centraldash.central

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/** Busca la central por mDNS (servicio `_exsapo._tcp.`). Devuelve su IP o null si no aparece. */
object CentralDiscovery {
    private const val SERVICE_TYPE = "_exsapo._tcp."

    @Suppress("DEPRECATION")
    suspend fun discover(context: Context, timeoutMs: Long = 8_000): String? {
        val nsd = context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
        var active: NsdManager.DiscoveryListener? = null
        return try {
            withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<String?> { cont ->
                    val listener = object : NsdManager.DiscoveryListener {
                        override fun onServiceFound(info: NsdServiceInfo) {
                            nsd.resolveService(info, object : NsdManager.ResolveListener {
                                override fun onResolveFailed(i: NsdServiceInfo, code: Int) {}
                                override fun onServiceResolved(i: NsdServiceInfo) {
                                    val host = i.host?.hostAddress
                                    if (host != null && cont.isActive) cont.resume(host)
                                }
                            })
                        }
                        override fun onDiscoveryStarted(type: String) {}
                        override fun onDiscoveryStopped(type: String) {}
                        override fun onServiceLost(info: NsdServiceInfo) {}
                        override fun onStartDiscoveryFailed(type: String, code: Int) {
                            if (cont.isActive) cont.resume(null)
                        }
                        override fun onStopDiscoveryFailed(type: String, code: Int) {}
                    }
                    active = listener
                    nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
                }
            }
        } finally {
            active?.let { runCatching { nsd.stopServiceDiscovery(it) } }
        }
    }
}
