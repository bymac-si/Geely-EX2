package com.example.centraldash

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.centraldash.central.CentralClient
import com.example.centraldash.central.CentralDiscovery
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Mantiene viva la conexión con la central aunque la app no esté en pantalla (p. ej. con Android Auto). */
class TelemetryService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE,
        )
        if (job == null) {
            job = scope.launch {
                CentralClient {
                    Settings.host(this@TelemetryService) ?: CentralDiscovery.discover(this@TelemetryService)
                }.run()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        TelemetryRepo.setStatus("desconectado")
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Conexión con la central", NotificationManager.IMPORTANCE_LOW)
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Central Dash")
            .setContentText("Leyendo datos del auto")
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "central_link"
        private const val NOTIF_ID = 1
    }
}
