package com.example.centraldash

import android.content.Context

object Settings {
    private const val FILE = "centraldash"
    private const val KEY_HOST = "central_host"

    fun host(ctx: Context): String? =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_HOST, null)?.takeIf { it.isNotBlank() }

    fun setHost(ctx: Context, host: String?) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY_HOST, host?.trim()).apply()
    }
}
