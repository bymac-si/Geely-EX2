package com.example.centraldash

import com.example.centraldash.model.Telemetry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Punto único de verdad: el cliente de la central publica aquí; la UI y la pantalla del auto leen. */
object TelemetryRepo {
    private val _state = MutableStateFlow(Telemetry())
    private val _status = MutableStateFlow("desconectado")

    val state: StateFlow<Telemetry> = _state
    val status: StateFlow<String> = _status

    fun publish(t: Telemetry) { _state.value = t }
    fun setStatus(s: String) { _status.value = s }
}
