package com.example.centraldash.apkshare

import java.io.File

object ApkSharingProvider {
    val instance: ApkSharing = object : ApkSharing {
        override val available = false
        override fun start(dir: File, pin: String): List<String>? = null
        override fun stop() {}
        override fun isRunning() = false
    }
}
