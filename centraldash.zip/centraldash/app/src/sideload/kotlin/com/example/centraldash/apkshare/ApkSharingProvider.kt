package com.example.centraldash.apkshare

import com.example.centraldash.TelemetryRepo
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.MessageDigest

object ApkSharingProvider {
    val instance: ApkSharing = HttpApkSharing()
}

/**
 * Servidor HTTP mínimo, de un solo hilo, pensado para unos minutos de uso:
 *  - exige ?pin=XXXXXX en cada petición;
 *  - solo sirve archivos .apk que existan en la carpeta indicada (sin rutas arbitrarias);
 *  - se apaga solo a los 10 minutos;
 *  - se niega a servir si la central reporta que el auto va a más de 3 km/h.
 */
class HttpApkSharing : ApkSharing {
    override val available = true

    @Volatile private var server: ServerSocket? = null
    @Volatile private var deadlineMs = 0L

    override fun isRunning() = server?.isClosed == false

    override fun start(dir: File, pin: String): List<String>? {
        stop()
        val ss = try { ServerSocket(PORT) } catch (e: Exception) { return null }
        server = ss
        deadlineMs = System.currentTimeMillis() + TTL_MS
        ss.soTimeout = 1_000
        Thread({ acceptLoop(ss, dir, pin) }, "apk-share").apply { isDaemon = true; start() }
        return localIpv4s().map { "http://$it:$PORT/?pin=$pin" }
    }

    override fun stop() {
        runCatching { server?.close() }
        server = null
    }

    private fun acceptLoop(ss: ServerSocket, dir: File, pin: String) {
        while (!ss.isClosed && System.currentTimeMillis() < deadlineMs) {
            try {
                ss.accept().use { handle(it, dir, pin) }
            } catch (e: SocketTimeoutException) {
                // vuelve a comprobar el plazo
            } catch (e: Exception) {
                if (ss.isClosed) break
            }
        }
        runCatching { ss.close() }
    }

    private fun handle(s: Socket, dir: File, pin: String) {
        s.soTimeout = 10_000
        val reader = s.getInputStream().bufferedReader(Charsets.ISO_8859_1)
        val requestLine = reader.readLine() ?: return
        var n = 0
        while (true) { // descarta cabeceras (con tope)
            val h = reader.readLine() ?: break
            if (h.isEmpty() || ++n > 64) break
        }
        val out = s.getOutputStream()
        val parts = requestLine.split(' ')
        if (parts.size < 2 || parts[0] != "GET") return reply(out, 405, "text/plain", "Método no permitido")

        val target = parts[1]
        val path = target.substringBefore('?')
        val query = target.substringAfter('?', "")
        val given = query.split('&').firstOrNull { it.startsWith("pin=") }?.removePrefix("pin=") ?: ""
        if (!MessageDigest.isEqual(given.toByteArray(), pin.toByteArray())) {
            return reply(out, 403, "text/plain", "PIN incorrecto")
        }
        val speed = TelemetryRepo.state.value.speedKmh
        if (speed != null && speed > 3.0) {
            return reply(out, 403, "text/plain", "El auto está en movimiento")
        }

        val apks = dir.listFiles { f -> f.isFile && f.name.endsWith(".apk", ignoreCase = true) }
            ?.sortedBy { it.name } ?: emptyList()

        if (path == "/") {
            val items = apks.joinToString("") { f ->
                val name = esc(f.name)
                val enc = java.net.URLEncoder.encode(f.name, "UTF-8")
                val kb = f.length() / 1024
                "<li><a href=\"/f/$enc?pin=$pin\">$name</a> ($kb KB)</li>"
            }
            val list = items.ifEmpty { "<li>(ninguno)</li>" }
            val html = "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width'>" +
                "<h2>APKs disponibles</h2><ul>$list</ul>"
            return reply(out, 200, "text/html; charset=utf-8", html)
        }
        if (path.startsWith("/f/")) {
            val wanted = java.net.URLDecoder.decode(path.removePrefix("/f/"), "UTF-8")
            val file = apks.firstOrNull { it.name == wanted } ?: return reply(out, 404, "text/plain", "No existe")
            val safeName = file.name.replace("\"", "")
            val size = file.length()
            out.write(
                ("HTTP/1.1 200 OK\r\nContent-Type: application/vnd.android.package-archive\r\n" +
                    "Content-Length: $size\r\n" +
                    "Content-Disposition: attachment; filename=\"$safeName\"\r\n" +
                    "Cache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray(Charsets.ISO_8859_1)
            )
            file.inputStream().use { it.copyTo(out) }
            out.flush()
            return
        }
        reply(out, 404, "text/plain", "No existe")
    }

    private fun reply(out: java.io.OutputStream, code: Int, type: String, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        out.write(
            ("HTTP/1.1 $code X\r\nContent-Type: $type\r\nContent-Length: ${bytes.size}\r\n" +
                "Cache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray(Charsets.ISO_8859_1)
        )
        out.write(bytes)
        out.flush()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun localIpv4s(): List<String> =
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .filter { it.isSiteLocalAddress }
            .mapNotNull { it.hostAddress }

    companion object {
        const val PORT = 8088
        const val TTL_MS = 10 * 60 * 1000L
    }
}
