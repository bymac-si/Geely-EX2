# Central Dash

App Android propia que lee los datos del auto desde la central (multimedia) y los muestra
en el teléfono y en Android Auto (categoría IoT). Implementación desde cero; el protocolo está
documentado en `docs/PROTOCOLO_CENTRAL.md`.

> **Estado: primera entrega, SIN COMPILAR.** Se escribió sin Android SDK ni red. Ábrelo en Android Studio,
> deja que sincronice Gradle y corrige lo que salga (versiones de plugins/librerías incluidas). Cambia el
> `applicationId` en `app/build.gradle.kts`.

## Qué hay
- `central/` cliente TCP (puerto 47800), parser y descubrimiento mDNS.
- `TelemetryService` mantiene la conexión en primer plano.
- `car/` pantalla de Android Auto (PaneTemplate, 4 filas).
- `apkshare/` (solo sabor `sideload`): sirve APKs por HTTP en la red local para instalarlos desde el
  navegador de la multimedia. PIN de 6 dígitos, se apaga a los 10 min, no sirve si el auto va a >3 km/h.

## Probar sin el auto
1. `python3 tools/fake_central.py` en tu PC (misma red que el teléfono).
2. En la app, escribe la IP de tu PC y pulsa "Conectar".

## Compilar
- **En la nube (sin instalar nada):** sube esta carpeta a un repositorio de GitHub. La pestaña *Actions* corre
  `.github/workflows/build.yml` y deja el APK debug (firmado con la clave de depuración) como artefacto descargable.
  Las versiones de las acciones y de Gradle no pude verificarlas: si falla, el log dirá cuál.
- **En tu PC:** Android Studio (abrir la carpeta, sincronizar, ejecutar el sabor `sideloadDebug`).
- `assembleSideloadDebug` / `assemblePlayDebug` (sabores `sideload` y `play`).
- Tests del parser: `testSideloadDebugUnitTest`.

## Pendiente / por verificar
- Captura real del puerto 47800 para cerrar el esquema (ver sección 5 del protocolo).
- Android 15+ limita los servicios en primer plano; se usó `connectedDevice`, confirmar que aplica a una conexión WiFi.
- Verificar si tu versión de Android exige un permiso de red local antes de subir `targetSdk`.
- Release de Android Auto: la lista de hosts permitidos usa la muestra de la librería; revisarla.
- Firmas distintas entre `play` y `sideload`: no se actualizan entre sí.
